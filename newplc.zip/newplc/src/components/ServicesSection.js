import React from "react";

const ServicesSection = () => (
  <section className="services-section container">
    <h2 className="section-title">Automation Services</h2>
    <div className="services-grid">
      <div className="service-card">
        <div className="service-title">Remote Automation</div>
        <div className="service-description">Setup and support for remote PLC and SCADA systems.</div>
        <ul className="service-features">
          <li className="feature-item">24/7 Monitoring</li>
          <li className="feature-item">Secure VPN Access</li>
          <li className="feature-item">Live Data Streaming</li>
        </ul>
      </div>
      <div className="service-card">
        <div className="service-title">Digital Store Integration</div>
        <div className="service-description">Sell and deliver digital automation products online.</div>
        <ul className="service-features">
          <li className="feature-item">Instant Download</li>
          <li className="feature-item">License Management</li>
          <li className="feature-item">Payment Integration</li>
        </ul>
      </div>
    </div>
  </section>
);

export default ServicesSection;
