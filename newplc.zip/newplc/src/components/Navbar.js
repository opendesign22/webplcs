import React from "react";
import { Link } from "react-router-dom";
import "../App.css";

const Navbar = () => (
  <nav className="navbar">
    <div className="logo"><strong>TIA Portal Blocks</strong></div>
    <div className="nav-links">
      <Link to="/">Home</Link>
      <Link to="/product">Product</Link>
      <Link to="/blog">Blog</Link>
      <Link to="/contact">Contact</Link>
      <Link to="/dashboard">Dashboard</Link>
    </div>
  </nav>
);

export default Navbar;
