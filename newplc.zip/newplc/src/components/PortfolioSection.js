import React from "react";

const PortfolioSection = () => (
  <section className="portfolio-section container">
    <h2 className="section-title">Portfolio & Blog</h2>
    <div className="blog-grid">
      {/* Example blog cards, replace with dynamic data as needed */}
      <div className="blog-card">
        <div className="blog-img" style={{background:'#123'}}></div>
        <div className="blog-content">
          <div className="blog-date">Aug 2025</div>
          <div className="blog-title">TIA Portal Project Success</div>
          <div className="blog-excerpt">How we delivered a custom automation block for a major client using Siemens TIA Portal.</div>
        </div>
      </div>
      <div className="blog-card">
        <div className="blog-img" style={{background:'#234'}}></div>
        <div className="blog-content">
          <div className="blog-date">Jul 2025</div>
          <div className="blog-title">WinCC UX/UI Best Practices</div>
          <div className="blog-excerpt">Tips for designing modern SCADA dashboards and HMIs with WinCC and TIA Portal.</div>
        </div>
      </div>
    </div>
  </section>
);

export default PortfolioSection;
