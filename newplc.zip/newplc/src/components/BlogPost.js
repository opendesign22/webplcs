import React from "react";

const BlogPost = () => (
  <section className="blog-section" id="blog">
    <div className="blog-title">Getting Started with TIA Portal V17</div>
    <div className="blog-content">
      <p>Learn how to use and integrate our block project in your Siemens TIA Portal environment. Step-by-step guides, tips, and best practices for industrial automation.</p>
      <ul>
        <li>Importing blocks into your project</li>
        <li>Connecting to WinCC and SCADA dashboards</li>
        <li>Customizing for your application</li>
        <li>Support for advanced features</li>
      </ul>
    </div>
  </section>
);

export default BlogPost;
