import React from "react";

const StoreSection = () => (
  <section className="store-section container">
    <h2 className="section-title">Digital Automation Store</h2>
    <div className="products-grid">
      <div className="product-card">
        <div className="product-title">TIA Portal Block Project</div>
        <div className="product-description">Reusable PLC blocks for Siemens TIA Portal, ready for integration.</div>
        <ul className="product-features">
          <li className="feature-item">WinCC & SCADA Compatible</li>
          <li className="feature-item">Comprehensive Documentation</li>
          <li className="feature-item">Optimized for Reliability</li>
        </ul>
        <div className="product-footer">
          <span className="product-price">$199</span>
          <button className="buy-button">Buy Now</button>
        </div>
      </div>
    </div>
  </section>
);

export default StoreSection;
