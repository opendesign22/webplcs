import React from "react";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";

const stripePromise = loadStripe("YOUR_STRIPE_PUBLIC_KEY");

const Payment = () => (
  <Elements stripe={stripePromise}>
    <div className="payment-section">
      <h2>Payment</h2>
      {/* Stripe payment form goes here */}
      <p>Integrate Stripe Checkout or Payment Element here.</p>
    </div>
  </Elements>
);

export default Payment;
