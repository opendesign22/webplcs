import React from "react";

const ContactForm = () => (
  <section className="contact-section" id="contact">
    <div className="contact-title">Contact & Purchase</div>
    <form className="contact-form">
      <input type="text" placeholder="Your Name" required />
      <input type="email" placeholder="Your Email" required />
      <textarea rows="5" placeholder="Your Message" required></textarea>
      <button type="submit">Send Inquiry</button>
    </form>
  </section>
);

export default ContactForm;
