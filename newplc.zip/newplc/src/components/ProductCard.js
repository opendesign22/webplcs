import React from "react";

const ProductCard = () => (
  <section className="product-section" id="product">
    <div className="product-title">TIA Portal Block Project</div>
    <div className="product-desc">This block project is programmed in Siemens TIA Portal and includes:
      <ul>
        <li>Reusable PLC blocks for industrial automation</li>
        <li>Easy integration with WinCC and SCADA systems</li>
        <li>Comprehensive documentation and support</li>
        <li>Optimized for reliability and performance</li>
      </ul>
    </div>
    <div className="price">$199</div>
    <a href="#contact"><button className="cta-btn">Order Now</button></a>
  </section>
);

export default ProductCard;
