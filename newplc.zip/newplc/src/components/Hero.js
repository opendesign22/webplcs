import React from "react";

const Hero = () => (
  <section className="hero">
    <h1>Sell Your TIA Portal Block Project</h1>
    <p>Professional, ready-to-use blocks for Siemens TIA Portal. Boost your automation projects with proven, reliable code.</p>
    <a href="#contact"><button className="cta-btn">Buy Now</button></a>
  </section>
);

export default Hero;
