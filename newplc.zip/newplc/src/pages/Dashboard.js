import React from "react";
import Navbar from "../components/Navbar";
import Auth from "../components/Auth";

const Dashboard = () => (
  <>
    <Navbar />
    <Auth />
    {/* Add user dashboard features here */}
  </>
);

export default Dashboard;
