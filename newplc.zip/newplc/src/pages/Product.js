import React from "react";
import Navbar from "../components/Navbar";
import ProductCard from "../components/ProductCard";
import Payment from "../components/Payment";
import StoreSection from "../components/StoreSection";

const Product = () => (
  <>
    <Navbar />
    <StoreSection />
    <ProductCard />
    <Payment />
  </>
);

export default Product;
