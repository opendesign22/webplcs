import React from "react";
import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import ProductCard from "../components/ProductCard";
import BlogPost from "../components/BlogPost";
import ContactForm from "../components/ContactForm";
import PortfolioSection from "../components/PortfolioSection";
import ServicesSection from "../components/ServicesSection";
import StoreSection from "../components/StoreSection";

const Home = () => (
  <>
    <Navbar />
    <Hero />
    <PortfolioSection />
    <ServicesSection />
    <StoreSection />
    <ProductCard />
    <BlogPost />
    <ContactForm />
  </>
);

export default Home;
