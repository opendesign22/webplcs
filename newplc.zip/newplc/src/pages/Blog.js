import React from "react";
import Navbar from "../components/Navbar";
import BlogPost from "../components/BlogPost";
import PortfolioSection from "../components/PortfolioSection";

const Blog = () => (
  <>
    <Navbar />
    <PortfolioSection />
    <BlogPost />
  </>
);

export default Blog;
